﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=13.3
@EndOfDesignText@
'Code module
'Subs in this code module will be accessible from all modules.
Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	
End Sub

Sub Predict(et() As Double) As Double
	
	Dim xs(13) As Double
	For i=0 To 12
		Dim meanS() As String=Main.mean.Get(i+1)
		Dim scaleS() As String=Main.scale.Get(i+1)
		xs(i) = (et(i)-meanS(0))/scaleS(0)
	Next
	Dim a1(234) As Double
	For i=0 To 233
		Dim coefs0S() As String=Main.coefs0.Get(i+1)
		Dim intercepts0S() As String=Main.intercept0.get(i+1)
		For j=0 To 12
			a1(i) = a1(i) + xs(j)*coefs0S(j)
		Next
		a1(i) =a1(i)+intercepts0S(0)
		a1(i) = 1/(1+Power(cE, -a1(i))) 'logistic= 1/(1+e^(-x))
	Next
	Dim a2 As Double
	Dim coefs1S() As String=Main.coefs1.Get(1)
	For i=0 To 233
		a2 = a2 + a1(i)*coefs1S(i)
	Next
	Dim intercepts1S() As String= Main.intercept1.get(1)
	a2=a2+intercepts1S(0)
	Return a2
End Sub