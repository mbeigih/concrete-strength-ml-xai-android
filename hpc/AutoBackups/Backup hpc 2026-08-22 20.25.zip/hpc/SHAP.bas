﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=13.3
@EndOfDesignText@

Sub Process_Globals

	Private FeatureMeans(8) As Double= Array As Double(250, 0, 0, 182, 3.3, 1005.6, 750, 28)

End Sub

'====================================================
' SHAP
'====================================================
Public Sub CalculateSHAP(x() As Double) As Double()
	Dim M As Int = 8

	Dim shap(M) As Double

	'----------------------------------------
	' For each feature i
	'----------------------------------------
	For i = 0 To M - 1
		
		Dim phi As Double = 0

		'----------------------------------------
		' Enumerate all subsets S
		'----------------------------------------
		For subset = 0 To Bit.ShiftLeft(1, M) - 1
			'skip subsets containing i
			If Bit.And(subset, _
                Bit.ShiftLeft(1, i)) <> 0 Then Continue

			'size of subset
			Dim s As Int = CountBits(subset)

			'Shapley weight
			Dim weight As Double = _
                Factorial(s) * _
                Factorial(M - s - 1) / _
                Factorial(M)

			'----------------------------------------
			' f(S)
			'----------------------------------------
			Dim xS(8) As Double

			For j = 0 To M - 1

				If Bit.And(subset, _
                    Bit.ShiftLeft(1, j)) <> 0 Then

					xS(j) = x(j)

				Else

					xS(j) = FeatureMeans(j)

				End If

			Next

			Dim predS As Double = _
                XGBoost.Predict(xS)

			'----------------------------------------
			' f(S U {i})
			'----------------------------------------
			xS(i) = x(i)

			Dim predSi As Double = _
                XGBoost.Predict(xS)
			'marginal contribution
			Dim marginal As Double = _
                predSi - predS

			phi = phi + weight * marginal

		Next

		shap(i) = phi

	Next

	Return shap

End Sub

'====================================================
' Count set bits
'====================================================
Private Sub CountBits(x As Int) As Int

	Dim cnt As Int = 0

	Do While x > 0

		If Bit.And(x,1) = 1 Then
			cnt = cnt + 1
		End If

		x = Bit.UnsignedShiftRight(x,1)

	Loop

	Return cnt

End Sub

'====================================================
' Factorial
'====================================================
Private Sub Factorial(n As Int) As Double

	If n <= 1 Then Return 1

	Dim f As Double = 1

	For i = 2 To n
		f = f * i
	Next

	Return f

End Sub

'====================================================
' Full explanation
'====================================================
Public Sub ExplainPrediction(x() As Double) As Map

	Dim result As Map
	result.Initialize

	Dim shap() As Double = _
        CalculateSHAP(x)

	'baseline
	Dim baseX(8) As Double

	For i = 0 To 7
		baseX(i) = FeatureMeans(i)
	Next

	Dim baseValue As Double = _
        XGBoost.Predict(baseX)

	Dim pred As Double = _
        XGBoost.Predict(x)

	Dim sumPred As Double = baseValue

	For i = 0 To 7
		sumPred = sumPred + shap(i)
	Next

	result.Put("base_value", baseValue)
	result.Put("prediction", pred)
	result.Put("sum_prediction", sumPred)
	result.Put("shap_values", shap)

	Return result

End Sub